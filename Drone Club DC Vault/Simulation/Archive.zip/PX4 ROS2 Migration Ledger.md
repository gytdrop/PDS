---
title: PX4 ROS2 Migration Ledger
aliases: [PX4 Migration Ledger, ArduPilot to PX4 Migration, PX4 Transition Blueprint]
tags: [px4, ros2, migration, ledger, gazebo-harmonic, micro-xrce-dds, simulation]
created: 2026-10-15
status: draft
---

# 📜 Drone Club: ArduPilot to PX4 + ROS 2 Simulation Migration Ledger

> [!abstract] Architectural Purpose
> This ledger documents the safe decommissioning of the legacy **ArduPilot SITL** stack (external socket plugins, MAVLink proxy routing) and details the systematic installation and integration of the **PX4-Autopilot + Gazebo Harmonic + Micro XRCE-DDS Agent + ROS 2** native autonomy stack on **Arch Linux**.

---

## 🗺️ High-Level Migration Ledger Matrix

```mermaid
flowchart TD
    subgraph Decommission ["Phase 1: Detach & Decommission ArduPilot"]
        D1["Kill active sim sessions & ports"]
        D2["Archive sample_drone_flight.py"]
        D3["Clean ~/.bashrc & ~/.zshrc"]
        D4["Purge stale symlinks in 'installed gigs/'"]
        D5["Remove ~/ardupilot, ~/ardupilot_gazebo, ~/venv-ardupilot"]
        D1 --> D2 --> D3 --> D4 --> D5
    end

    subgraph Install ["Phase 2: Install Next Gigs"]
        I1["Clone & Build PX4-Autopilot SITL"]
        I2["Build & Install Micro XRCE-DDS Agent"]
        I3["Initialize px4_ros2_ws (px4_msgs, px4_ros_com)"]
        I4["Symlink binaries to 'installed gigs/'"]
        I1 --> I2 --> I3 --> I4
    end

    subgraph Verify ["Phase 3: 4-Gate Safe Integration"]
        G1["Gate 1: PX4 SITL + Gazebo Harmonic (commander takeoff)"]
        G2["Gate 2: QGroundControl Telemetry (UDP 14550)"]
        G3["Gate 3: Micro XRCE-DDS Middleware (UDP 8888)"]
        G4["Gate 4: ROS 2 Offboard Control (5m hover)"]
        G1 --> G2 --> G3 --> G4
    end

    Decommission --> Install --> Verify
```

---

## Part 1: Detachment & Decommissioning Ledger (ArduPilot)

### 1.1 Complete Legacy Footprint Inventory

| Component / Path | Type / Size | Action | Justification |
| :--- | :--- | :--- | :--- |
| **`~/ardupilot`** | Git Repo + Build Artifacts (~2.1 GB) | **Decommission & Remove** | ArduPilot Copter SITL firmware and waf binaries. Obsolete under PX4. |
| **`~/ardupilot_gazebo`** | Plugin Repo + CMake Build (~181 MB) | **Decommission & Remove** | Third-party Gazebo plugin for ArduPilot lockstep. Not used by PX4. |
| **`~/venv-ardupilot`** | Python 3 Virtualenv (~1.1 GB) | **Decommission & Remove** | Contains `pymavlink`, `MAVProxy`, `dronecan`. Will be replaced by clean PX4 tooling. |
| **`~/.mavproxy/`** | Config & Logs (~1 MB) | **Remove** | MAVProxy ground station cache. |
| **`installed gigs/ardupilot`** | Symlink | **Remove** | Stale link to `~/ardupilot`. |
| **`installed gigs/ardupilot_gazebo`** | Symlink | **Remove** | Stale link to `~/ardupilot_gazebo`. |
| **`installed gigs/venv-ardupilot`** | Symlink | **Remove** | Stale link to `~/venv-ardupilot`. |
| **`installed gigs/sim_vehicle.py`** | Symlink | **Remove** | ArduPilot launcher script. |
| **`installed gigs/mavproxy.py`** | Symlink | **Remove** | MAVProxy CLI. |
| **`installed gigs/libArduPilotPlugin.so`** (and related .so) | Symlinks (4 files) | **Remove** | Stale links to `ardupilot_gazebo/build/`. |
| **`sample_drone_flight.py`** | Script (10.6 KB) | **Archive to `legacy_ardupilot/`** | MAVLink square mission. Retained as reference for writing ROS 2 offboard equivalent. |
| **`~/.bashrc` (lines 14–23)** | Shell Exports | **Sanitize** | Auto-activates `venv-ardupilot` and injects dead ArduPilot paths into every terminal. |
| **`~/.zshrc` (lines 112–119)** | Shell Exports | **Sanitize** | Injects dead ArduPilot paths into Zsh terminals. |

### 1.2 Preserved Components (DO NOT TOUCH)
- **Gazebo Sim (Harmonic 8.15.0)** (`/usr/bin/gz`): PX4 SITL natively targets Gazebo Harmonic. Keep intact.
- **QGroundControl** (`~/QGroundControl.AppImage`): Native GCS for PX4. Preserved and linked.
- **Physics Plugins** (`/usr/lib/gz-physics-7/engine-plugins`): Required by Gazebo. Keep intact.

### 1.3 Step-by-Step Detachment Execution Script

```bash
# 1. Kill any active simulation sessions
./"installed gigs"/start_sim.sh --kill || true
pkill -9 -f "arducopter" || true
pkill -9 -f "gz sim" || true
pkill -9 -f "mavproxy" || true

# 2. Archive legacy flight script
mkdir -p legacy_ardupilot
mv sample_drone_flight.py legacy_ardupilot/

# 3. Clean environment files
sed -i '/venv-ardupilot/d' ~/.bashrc
sed -i '/ardupilot/d' ~/.bashrc
sed -i '/venv-ardupilot/d' ~/.zshrc
sed -i '/ardupilot/d' ~/.zshrc

# 4. Remove stale symlinks
rm -f "installed gigs"/ardupilot "installed gigs"/ardupilot_gazebo "installed gigs"/venv-ardupilot
rm -f "installed gigs"/sim_vehicle.py "installed gigs"/mavproxy.py "installed gigs"/libArduPilotPlugin.so* "installed gigs"/lib*Plugin.so

# 5. Free disk space (~3.4 GB)
rm -rf ~/ardupilot ~/ardupilot_gazebo ~/venv-ardupilot ~/.mavproxy
```

---

## Part 2: Installation Ledger for Next Necessary Gigs

### 2.1 OS Context: Arch Linux Specifics
> [!WARNING]
> Upstream PX4 docs recommend `bash ./Tools/setup/ubuntu.sh --no-nuttx`. Because this system runs **Arch Linux**, `ubuntu.sh` will fail. We configure dependencies using native Arch packages (`pacman`), a dedicated virtualenv (`~/venv-px4`), and colcon for ROS 2.

### 2.2 The 4 Essential New Gigs

#### 1. PX4-Autopilot Source & SITL Build
- **Repository:** `https://github.com/PX4/PX4-Autopilot.git`
- **Target:** `~/PX4-Autopilot`
- **Execution Target:**
  ```bash
  cd ~/PX4-Autopilot
  make px4_sitl gz_x500
  ```

#### 2. Micro XRCE-DDS Agent
- **Repository:** `https://github.com/eProsima/Micro-XRCE-DDS-Agent.git`
- **Target:** `~/Micro-XRCE-DDS-Agent`
- **Port:** UDP `8888`
- **Execution:**
  ```bash
  MicroXRCEAgent udp4 -p 8888
  ```

#### 3. ROS 2 Workspace (`~/px4_ros2_ws`)
- **Repositories:**
  - `https://github.com/PX4/px4_msgs.git`
  - `https://github.com/PX4/px4_ros_com.git`
- **Build:**
  ```bash
  mkdir -p ~/px4_ros2_ws/src
  cd ~/px4_ros2_ws/src
  git clone https://github.com/PX4/px4_msgs.git
  git clone https://github.com/PX4/px4_ros_com.git
  cd ~/px4_ros2_ws
  colcon build --symlink-install --packages-select px4_msgs px4_ros_com
  ```

#### 4. QGroundControl & Gazebo Harmonic
- Retain existing `~/QGroundControl.AppImage` and `/usr/bin/gz`.

---

## Part 3: Safe Integration Ledger (4-Gate Verification)

### 🛡️ Gate 1: Pure PX4 SITL + Gazebo Harmonic
- **Command:** `cd ~/PX4-Autopilot && make px4_sitl gz_x500`
- **Pass Criteria:** Drone model spawns in Gazebo, `pxh>` prompt opens, `commander takeoff` climbs to 2.5m and hovers, `commander land` lands cleanly.

### 🛡️ Gate 2: QGroundControl Telemetry
- **Command:** `~/QGroundControl.AppImage &`
- **Pass Criteria:** Connects automatically over UDP 14550, HUD artificial horizon active, battery and GPS lock healthy.

### 🛡️ Gate 3: Micro XRCE-DDS Middleware Bridge
- **Command:** `MicroXRCEAgent udp4 -p 8888`
- **Pass Criteria:** Agent detects PX4 client connection, creates uORB pub/sub entities without dropouts.

### 🛡️ Gate 4: ROS 2 Offboard Control & Trajectory Execution
- **Command:**
  ```bash
  source ~/px4_ros2_ws/install/setup.bash
  ros2 run px4_ros_com offboard_control
  ```
- **Pass Criteria:** Drone switches to `OFFBOARD`, arms, ascends to 5.0m altitude, and hovers stably under 10Hz trajectory setpoints.

---

## 3-Terminal Execution Standard (Quick Reference)

```bash
# Terminal 1: Middleware Bridge
MicroXRCEAgent udp4 -p 8888

# Terminal 2: Flight Avionics + Physics Simulation
cd ~/PX4-Autopilot && make px4_sitl gz_x500_depth

# Terminal 3: Companion ROS 2 Offboard Autonomy
cd ~/px4_ros2_ws && source install/setup.bash && ros2 run px4_ros_com offboard_control
```

---

## 🔗 Cross-Links & Related Notes
- [[Welcome|Vault Index]]
- [[Robotics Simulation Pipeline]]
- [Installed Tools & Binaries (`installed gigs/`)](file:///home/gytdrop/Documents/PROJECTS/DC-%20Drone%20Club/installed%20gigs/README.md)
